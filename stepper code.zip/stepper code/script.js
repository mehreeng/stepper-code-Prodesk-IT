const stepLabels = ["Start", "Step 1", "", "", ""];
const totalSteps = stepLabels.length;
let currentStep = 1;

const container = document.getElementById("progressContainer");

function renderSteps() {
  container.innerHTML = `
    <div class="progress-line"></div>
    <div class="progress-line-fill" id="progressFill"></div>
  `;

  for (let i = 0; i < totalSteps; i++) {
    const step = document.createElement("div");
    step.classList.add("step");

    const circle = document.createElement("div");
    circle.classList.add("circle");

    if (i <= currentStep) {
      step.classList.add("active");
    } else {
      step.classList.add("inactive");
    }

    step.appendChild(circle);

    const label = document.createElement("div");
    label.classList.add("label");
    label.innerText = stepLabels[i];
    step.appendChild(label);

    container.appendChild(step);
  }

  const fill = document.getElementById("progressFill");
  const percentage = (currentStep / (totalSteps - 1)) * 80;
  fill.style.width = `${percentage}%`;

  document.getElementById("prevBtn").disabled = currentStep === 0;
  document.getElementById("nextBtn").disabled = currentStep === totalSteps - 1;
}

function nextStep() {
  if (currentStep < totalSteps - 1) {
    currentStep++;
    renderSteps();
  }
}

function prevStep() {
  if (currentStep > 0) {
    currentStep--;
    renderSteps();
  }
}

renderSteps();
